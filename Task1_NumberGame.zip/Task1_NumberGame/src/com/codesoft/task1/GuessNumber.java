package com.codesoft.task1;
import java.util.Scanner;
public class GuessNumber {
	public int guessNum;
	public static int attempt=0;
	private static int randomNum=50;
	public int diff;
	public void range()
	{
		
		if( randomNum>=1&&randomNum<=100)
		{    
		     guess();
		}
		else
		{
			System.out.println("Random Number should in between 1 to 100");
		}
	}
	public void guess()
	{  
		Scanner sc=new Scanner(System.in);
		System.out.println("-------------Welcome to Number Game---------------------");
		System.out.println("We are providing 10 Attempt to You!! Best of Luck");
		do {
		
		System.out.println("Your Attempt : "+attempt);
		System.out.println("Enter GuessNum : ");
		guessNum=sc.nextInt();
		if(guessNum<0||guessNum>=100)
		{
			System.out.println(" Please Enter in Between 1 to 100");
			continue;
		} 
		attempt++;
		if(attempt==10)
		{
			System.out.println("Attempt Over(Your Limit upto 10");
			continue;
		}
	    diff=Math.abs(guessNum-randomNum);
	    if(diff==50)
	    {
	    	System.out.println("Guess number and Random number difference is : "+diff);
	    }
	    else if(diff==0)
	    {
	    	System.out.println("Matching You are Win!!");
	    	break;
	
	    }
	    else if(diff>=1&&diff<=5)
	    {
	    	System.out.println("Your are very closed Differene is : "+diff);
	    }
	    else if(diff>=6&&diff<=10)
	    {
	    	System.out.println("Little Bit closed : Difference is : "+diff);
	    }
	    else if(diff>=20&&diff<=80)
	    {
	    	System.out.println("Your are Very Low : Difference is :"+diff);
	    }
		}while(guessNum!=randomNum||attempt!=10);
	}
	public void attempts()
	{
	   System.out.println("You Attempt : " +attempt);
	}
}