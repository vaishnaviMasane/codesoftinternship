package com.codesoft.task1;

public class Score {
public void scoreAttempt()
{
	if(GuessNumber.attempt==0)
	{
		System.out.println("You are won The Match : Score 100%");
	}
	else if(GuessNumber.attempt>0&&GuessNumber.attempt<=4)
	{
		System.out.println("You are won The Match : Score 90%");
	}
	else if(GuessNumber.attempt==5)
	{
		System.out.println("You are Won The Match : Score 75%");
	}
	else if(GuessNumber.attempt>=6&&GuessNumber.attempt<=9)
	{
		System.out.println("You are Won The Match : Score 50%");
	}
	else if(GuessNumber.attempt==10)
	{
		System.out.println("You are fail: Try Again");
	}
}
}
